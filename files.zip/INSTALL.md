# Recent work section — install

Your site is Next.js. This drops in as a client component; no new dependencies.

## 1. Copy the files

```
components/RecentWork.jsx   →  your repo's components folder
public/work/*.jpg           →  your repo's public/work/ folder
```

The eight images must land in `public/work/` exactly as named — the component
references them as `/work/calacatta-before.jpg` and so on.

## 2. Add it to a page

Home page, below the finishes collection:

```jsx
import RecentWork from '@/components/RecentWork';

// ...then in the page body, after the finishes section:
<RecentWork />
```

Or give it its own route at `/work`:

```jsx
// app/work/page.jsx
import RecentWork from '@/components/RecentWork';

export const metadata = {
  title: 'Recent work | Fuqua Finishes LLC',
  description:
    'Completed TRUbath porcelain bathroom installations in Houston — before and after, and how the system goes in.',
};

export default function Page() {
  return <RecentWork />;
}
```

If you add the route, add "Work" to the nav alongside Products, About and Contact.

## 3. Check it

`npm run dev`, then drag the slider on each project. Tab to it and use the arrow
keys — it should move with the keyboard too.

## Notes on how it's built

**Typography is inherited.** The component sets size, weight and spacing but not
the typeface, so it picks up whatever the rest of the site uses. A section in a
different font reads as a bolted-on widget.

**Colors are local variables** at the top of the section's CSS: `--rw-paper`,
`--rw-ink`, `--rw-muted`, `--rw-line`, `--rw-brass`. Change them there if they
don't sit right against your existing palette. The brass tone was picked from the
fixtures in the photographs.

**No `next/image`.** Plain `<img>` keeps the component portable and avoids
config surprises. If you'd rather have the optimization, swap the tags for
`next/image` and add `width`/`height` — the images are 1200×1600 for the
comparisons and 800×800 for the process strip.

**Only one thing animates:** the compare slider, responding to a drag. There are
no scroll-triggered entrances.

**Adding a third project later** means appending an object to the `PROJECTS`
array at the top of the file. The layout alternates sides automatically.
